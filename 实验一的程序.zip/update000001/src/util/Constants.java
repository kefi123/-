package util;

public class Constants {

	public static final int ROWPERPAGE =5;
}
