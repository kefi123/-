package util;

import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import domain.Department;
import domain.Page;

public class PageUtil {
	// 封装page
	public static Page makePage(int thispage, String tableName) {
		Page<Department> page = new Page<Department>();
		// --当前页
		page.setThispage(thispage);
		int rowperpage = Constants.ROWPERPAGE;
		// --共有多少行
		int countrow = getCountRow(tableName);
		page.setCountrow(countrow);
		// --共有多少页
		int countpage = countrow / rowperpage + (countrow % rowperpage == 0 ? 0 : 1);
		page.setCountpage(countpage);
		// --首页
		page.setFirstpage(1);
		// --尾页
		page.setLastpage(countpage);
		// --上一页
		page.setPrepage(thispage == 1 ? 1 : thispage - 1);
		// --下一页
		page.setNextpage(thispage == countpage ? countpage : thispage + 1);
		// --当前页数据
		List list = getCustByPage((thispage - 1) * rowperpage, rowperpage, tableName);
		page.setList(list);

		return page;
	}

	// 得到总行数
	public static int getCountRow(String tableName) {
		String sql = "select count(*) from !";
		sql = sql.replaceAll("!", tableName);
		try {
			QueryRunner runner = new QueryRunner(DbManager.getSource());
			return ((Long) runner.query(sql, new ScalarHandler())).intValue();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	// 得到当前页需要显示的信息
	public static List getCustByPage(int from, int count, String tableName) {
		String sql = "select * from ! limit ?,?";
		sql = sql.replaceAll("!", tableName);
		try {
			QueryRunner runner = new QueryRunner(DbManager.getSource());
			return runner.query(sql, new BeanListHandler<>(Department.class), from, count);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
