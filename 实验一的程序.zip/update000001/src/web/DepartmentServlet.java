package web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.Department;
import domain.Page;
import service.DepartmentService;

/**
 * Servlet implementation class Department
 */
@WebServlet("/DepartmentServlet")
public class DepartmentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private DepartmentService ds = new DepartmentService();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DepartmentServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");

		String method = req.getParameter("method");
		if (method.equals("findByPage"))
			findByPage(req, resp);
		else if (method.equals("findById"))
			findById(req, resp);
		else if (method.equals("update"))
			update(req, resp);
	}

	private void update(HttpServletRequest req, HttpServletResponse resp) {
		try {
			String name=req.getParameter("name");
			int id=Integer.parseInt(req.getParameter("id"));
			
			Department de=new Department();
			de.setId(id);
			de.setName(name);
			
			boolean result=ds.update(de);
			req.setAttribute("result", result);
			req.getRequestDispatcher("department/update.jsp").forward(req, resp);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
	}

	

	private void findById(HttpServletRequest req, HttpServletResponse resp) {
		try {
			int id=Integer.parseInt(req.getParameter("id"));
			Department department=ds.findById(id);
			req.setAttribute("department", department);
			req.getRequestDispatcher("department/update.jsp").forward(req, resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void findByPage(HttpServletRequest req, HttpServletResponse resp) {
		try {
			int thispage=Integer.parseInt(req.getParameter("thispage"));
			Page<Department> page= ds.findByPage(thispage);
			req.setAttribute("page", page);
			req.getRequestDispatcher("department/list.jsp").forward(req, resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
