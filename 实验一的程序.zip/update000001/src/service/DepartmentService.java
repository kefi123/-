package service;

import dao.DepartmentDao;
import domain.Department;
import domain.Page;
import util.PageUtil;

public class DepartmentService {
	private DepartmentDao dd = new DepartmentDao();

	public Department findById(int id) {
		// TODO Auto-generated method stub
		return dd.findById(id);
	}

	public boolean update(Department de) {
		return dd.updateDepartment(de);
	}

	@SuppressWarnings("unchecked")
	public Page<Department> findByPage(int thispage) {
		return PageUtil.makePage(thispage,"department");

	}
}
