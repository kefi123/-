package dao;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import domain.Department;
import util.DbManager;

public class DepartmentDao {
	
	public Department findById(int id) {
		Department de=null;
		try {
			String sql="select * from department where id=?";
			QueryRunner runner = new QueryRunner(DbManager.getSource());
			de=runner.query(sql,new BeanHandler<>(Department.class),id);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return de;
	}
	public boolean updateDepartment(Department de) {
		try {
			QueryRunner runner = new QueryRunner(DbManager.getSource());
			int result;
			result = runner.update("update department set name=? where id=?", de.getName(),de.getId());
			if (result == 1)
				return true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	
}
