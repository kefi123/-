/*
Navicat MySQL Data Transfer

Source Server         : mysql01
Source Server Version : 50614
Source Host           : localhost:3306
Source Database       : wljn01

Target Server Type    : MYSQL
Target Server Version : 50614
File Encoding         : 65001

Date: 2018-06-09 15:37:43
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `department`
-- ----------------------------
DROP TABLE IF EXISTS `department`;
CREATE TABLE `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '部门编号',
  `name` varchar(40) NOT NULL COMMENT '部门名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of department
-- ----------------------------
INSERT INTO `department` VALUES ('1', '徐猪猪');
INSERT INTO `department` VALUES ('2', '许磊');
INSERT INTO `department` VALUES ('3', '陶雨洁');
INSERT INTO `department` VALUES ('4', '杨寒寒');

-- ----------------------------
-- Table structure for `title`
-- ----------------------------
DROP TABLE IF EXISTS `title`;
CREATE TABLE `title` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of title
-- ----------------------------
